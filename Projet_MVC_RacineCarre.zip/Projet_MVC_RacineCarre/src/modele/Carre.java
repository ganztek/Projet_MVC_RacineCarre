package modele;

/**
 classe qui implemente l'interface de la racine carre
 */
public class Carre implements Conversion {
    @Override
    public double carre(double racine) {return (Math.sqrt(racine));}
}
