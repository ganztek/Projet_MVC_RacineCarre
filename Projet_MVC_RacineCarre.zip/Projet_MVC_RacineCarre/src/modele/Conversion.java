package modele;

/**
 interface qui definit la methode de conversion
 */
public interface Conversion {
    double carre(double racine);
}
